/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ********************************************************************
 ****/
#include <iostream>
#include <string>
//#include "account.h"
#include "loan.h"
using namespace std;

void Loan::update()
{
   float totalRate = currentBalance * rate;
   currentBalance += totalRate;
   displayTransaction(/*cout,*/ totalRate);   
}
void Loan::doTransaction(int amount)
{
   currentBalance += amount;
   displayTransaction(/*cout,*/ amount);
}
void Loan::displayBalance()
{
   cout << "new account...\n";
   cout << name <<" (loan):" << "balance is $" << currentBalance;
}

void Loan::displayTransaction(int amount)
{
    cout << name << "(loan): $" << amount << "applied to account\n"; 
}


//void Loan::displayRejected() const{}


