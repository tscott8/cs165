/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 *******************************************************************\
 *
 ****/

#include <iostream>

#include <string>
#include <fstream>
#include "account.h"
#include "savings.h"
#include "checking.h"
#include "loan.h"

using namespace std;

int main()
{

   char accountType;
   int accountNum;
   string nameIn;
   double initialBalance;
   float rateIn;
   int numChecks;
   float fee;
   int amount;
   ifstream fin("bank.txt");

   Account *list[100]; 
   while(!fin.eof())
   {
      fin >> accountType;
      switch (accountType)
      {
         case 's':
            fin >>accountNum>>nameIn>>initialBalance>>rateIn;
            list[accountNum] = new Savings(accountNum, initialBalance, nameIn, rateIn);
            break;

         case 'c':
            fin >>accountNum>>nameIn>>initialBalance>>fee;
             list[accountNum] = new Checking(accountNum, initialBalance, nameIn, fee);
            break;

         case 'l':
            fin >>accountNum>>nameIn>>initialBalance>>rateIn;
            list[accountNum] = new Loan(accountNum, initialBalance, nameIn, rateIn);    
            break;

         case 't':
            cout << "transaction...\n";
            fin >> accountNum >> amount;
            list[accountNum]->doTransaction(amount);
            break;
            
         case 'u':
            cout << "update...";
            fin >> accountNum;
            list[accountNum]->update();
            break;
      }
//display
   }
   for(int i = 0; i < 100; i++)
   {
       delete list[i];
   }
   fin.fail();
   fin.close();

return 0;
}


