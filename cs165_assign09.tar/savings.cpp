/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ********************************************************************
 ****/
#include <iostream>
#include <string>
//#include "account.h"
#include "savings.h"
using namespace std;

void Savings::update()
{
   double interest = currentBalance * rate;
   currentBalance += interest;
   displayTransaction(/*cout,*/ interest);
}

void Savings::doTransaction(int amount)
{
   currentBalance += amount;
   displayTransaction(/*cout,*/ amount);
}
void Savings::displayBalance()
{
   cout << "new account...\n";
   cout << name <<" (savings):" << "balance is $" << currentBalance;
}
void Savings::displayTransaction(int amount)
{
   cout << name << "(savings): $" << amount << "applied to account\n"; 
}
//void Savings::displayRejected() const{}
//{
//}
