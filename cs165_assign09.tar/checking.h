/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ********************************************************************
 ****/
#ifndef CHECKING_H
#define CHECKING_H
#include <iostream>
#include "account.h"

class Checking : public Account
{
  private:
   int numberOfChecks;
   float checkFee;
  public:
  Checking(int accountNumber,double currentBalance,std::string name,/*int numberOfChecks,*/ float checkFee)
      :Account(accountNumber,currentBalance,name)
   {
//      setNumberOfChecks(numberOfChecks);
      setCheckFee(checkFee);
   }
   //geter and setters
   int getNumberOfChecks(int numberOfChecks) {return numberOfChecks;}
   int setNumberOfChecks(int numberOfChecks)
   {
      this->numberOfChecks = numberOfChecks;
   }
   float getCheckFee(float checkFee) {return checkFee;}
   float setCheckFee(float checkFee)
   {
      this->checkFee = checkFee;
   }

   
   void update();
   void doTransaction(int amount);
   void displayBalance();
   void displayTransaction(int amount);
//   void displayRejected(); 
};

#endif



