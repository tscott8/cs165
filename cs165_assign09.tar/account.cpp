/*******************************************************************
****
* Program:
*    Assignment 09, Account
*    Brother Burton, CS165
* Author:
*    Tyler Scott
*  Summary:
*   
*   
*
*    Estimated:  9.0 hrs
*    Actual:     9.0 hrs
*      Comprehension of what to do.
********************************************************************
****/
//#include <iostream>
//#include <string>
//#include "account.h"
//using namespace std;

//Account::Account(int pCurrentBalance)
//{
//  currentBalance = pCurrentBalance;
//  numberOfTransactions = 0;
//}

/*void Account::deposit(int amount)
{
   currentBalance += amount;
   numberOfTransactions++;
}

void Account::withdraw(int amount)
{
 if (currentBalance >= amount)
 {
     currentBalance -= amount;
  }
  else
  {
     cout << "ERROR: Cannot withdraw " << amount << " since current balance is " << currentBalance << endl;
   }
 numberOfTransactions++;
}

*/

