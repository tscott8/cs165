/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ********************************************************************
 ****/
#ifndef LOAN_H
#define LOAN_H
#include <iostream>
#include "account.h"

class Loan : public Account
{ 
  private:
   float rate;
  public:
  Loan(int accountNumber,double currentBalance,std::string name,float rate)
     :Account(accountNumber,currentBalance,name)
   {
      setRate(rate);
   }
   //geter and setters
   float getRate(float rate) {return rate;}
   float setRate(float rate)
   {
      this->rate = rate;
   }
   void update();
   void doTransaction(int amount);
   void displayBalance();
   void displayTransaction(int amount);
//   void displayRejected();

   
};

#endif



