/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ********************************************************************
 ****/
#include <iostream>
#include <string>
//#include "account.h"
#include "checking.h"
using namespace std;

void Checking::update()
{
   double fee = -1 * currentBalance * checkFee;
   currentBalance += fee;
   displayTransaction(fee);
}
void Checking::doTransaction(int amount)
{
   if(amount>0)
      currentBalance+=amount;
   else
   {
      numberOfChecks++;
      if(currentBalance + amount >0)
         currentBalance += amount;
      else
         currentBalance -= 25;
   currentBalance += amount;
   displayTransaction(amount);
   }
}
void Checking::displayBalance()
{
   cout << "new account...\n";
   cout << name <<" (checking):" << "balance is $" << currentBalance;
}


void Checking::displayTransaction(int amount)
{
   cout << name << "(checking): $" << amount << "applied to account\n";\

}

   
//void Checking::displayRejected() const{}


