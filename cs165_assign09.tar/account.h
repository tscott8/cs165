/*******************************************************************
 ****
 * Program:
 *    Assignment 09, Account
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 *  Summary:
 *
 *
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ********************************************************************
 ****/
#ifndef ACCOUNT_H
#define ACCOUNT_H
#include <iostream>

class Account
{
  protected:

   double currentBalance;
   int accountNumber;
   std::string name;

  public:

   Account()
   {
      setCurrentBalance(1000);
      setAccountNumber(0);
      setName("[empty]");
   }

   Account(double currentBalance, int accountNumber, std::string name)
      {
      setCurrentBalance(currentBalance);
      setAccountNumber(accountNumber);
      setName(name);   
      }

   //getters and setters     
   double getCurrentBalance(double currentBalance) {return currentBalance;}
   double setCurrentBalance(double currentBalance)
   {
      this->currentBalance = currentBalance;
   }

   int getAccountNumber(int accountNumber) {return accountNumber;}
   int setAccountNumber(int accountNumber)
   {
      this->accountNumber = accountNumber;
   }

   std::string getName(std::string name) {return name;}
   std::string setName(std::string name)
   {
      this->name = name;
   }
   
   virtual void update()=0;
   virtual void doTransaction(int amount) = 0;
   virtual void displayBalance() = 0;
   virtual void displayTransaction(int amount) = 0;
//   virtual void displayRejected() = 0;
};
//   std:: ostream & operator << (std::ostream & out, const Account & list)
// {
//    list.displayBalance(out);
//    return out;
// }

#endif
