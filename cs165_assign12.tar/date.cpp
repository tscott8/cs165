/***********************************************************************
 * Program:
 *    Assignment 08, Time & Date
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 * Summary:
 *    Date.cpp is where the class in datee.h is processed and methods are
 *    are established, so that it knows what to do with the data given.
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ************************************************************************/
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "date.h"

//reassignment of assignment operator 
Date & Date :: operator = (const Date & rhs)
{
   this->setYear(rhs.getYear());
   this->setMonth(rhs.getMonth());
   this->setDay(rhs.getDay());
   this->setHours(rhs.getHours());
   this->setMinutes(rhs.getMinutes());
   this->setSeconds(rhs.getSeconds());
   return *this;
}

//another constructor finished
Date :: Date(const Date & rhs)
{
   *this =rhs;
}

//Prompt asks user to input data
void Date :: promptForDate()
{
   int month;
   int day;
   int year;

   cout << "Enter month: ";
   cin >> month;

   cout << "Enter day: ";
   cin >> day;
 
   cout << "Enter year: ";
   cin >> year;

   bool valid;
   do
   {
      valid = true;
      
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
         valid = false;
      }

      else
      {
         setMonth(month);
         setDay(day);
         setYear(year);
      }
      
   }while (!valid);
}

// pretty straight forward. displays, then displays time
void Date :: displayDate() const
{
   cout << month
        << "/" << day
        << "/" << year;   
   displayTime();   
}

//checks for leap year
bool Date :: isLeapYear(int year)
{
   if (year % 400 == 0)
      return true;
   if (year % 100 == 0)
      return false;
   if (year % 4 == 0)
      return true;
   else
      return false;
}

//checks how many days are in the given month.
int Date :: daysMonth(int month, int year)
{
   int numDays;
   if (month == 2 && isLeapYear(year))
      numDays = 29;
   else if (month == 2)
      numDays = 28;
   else if (month == 4 || month == 6 || month == 9 || month == 11\
            )
      numDays = 30;
   else
      numDays = 31;
   return numDays;
}

//adds rollover to years
void Date :: addYears(int year)
{
   this->year += year;
}

//adds rollover months to years
void Date :: addMonths(int month)
{
   this->month += month;
   if (this->month > 12)
   {
      this->month -= 12;
      addYears(1);
   }

}

//adds rollover days to months
void Date :: addDays(int day)
{
   int numDays = daysMonth(month, year);
   this->day += day;
   if (this->day > numDays)
   {
      this->day -= numDays;
      addMonths(1);
   }
}

//reassignment of the add hours, allows it to rollover to days.
void Date :: addHours(int hours)
{
   this->hours += hours;
   if (this->hours > 23)
   {
      this->hours -= 24;
      addDays(1);
   }
}

//reassignment of the exraction operator to add in the date part
ostream & operator << (ostream & out, const Date & rhs)
{
   out << setw(2) << setfill('0') << rhs.month
       << "/" << setw(2) << setfill('0') << rhs.day
       << "/"  << setw(4) << setfill('0') << rhs.year << " "
       << setw(2) << setfill('0') << rhs.hours << ":";
   out << setw(2) << setfill('0') << rhs.minutes;// << ":";
   //out << setw(2) << setfill('0') << rhs.seconds;
   return out;
}



   
