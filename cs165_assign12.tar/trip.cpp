//ugh

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstdlib>
using namespace std;

#include "trip.h" 
//#include "mileageClass.h"


string Trip::getFileName()
{
   cout << "Please enter a file name location: ";
   cin.ignore();
   getline(cin, fileName);
   return fileName;
}
void Trip::setFileName(string fileName)
{
   this->fileName=fileName;
}


  void Trip::testMileageChart(MileageMap &mileageChart)
{
   MileageData milesModes;
   string startCity;
   string destCity;
   char answer;
   char transportationMode;
   char tMode;
   bool mileageFound;
   int milesIn;
   string mode;
   cout << "\nStart City (e.g. Miami,FL): ";
   cin.ignore();
   getline(cin, startCity);
   
   while (startCity != "done")
   {
      cout << "End City   (e.g. Boise,ID): ";
      getline(cin, destCity);
      mileageFound = mileageChart.getMileage(startCity, destCity,
                                             milesModes);
      if (mileageFound)
      {
         cout << endl << "Distance from " << startCity << " to "
              <<  destCity
              << " = " << dec << milesModes.miles << " miles"
              << endl;
         cout << "Travel mode: Ox" << /*hex << */(int)milesModes.modes
              << endl;
      }
      else  // mileage between cities not found in mileage map
      {
         cout << "\n\tError: Mileage between " << startCity << " and "
              << destCity << " is unknown!\n";
         cout << "\nWould you still like to use these cities (y/n)? ";
         cin >> answer;
         if (toupper(answer) == 'Y')
         {
            cout << "Enter the mileage between " << startCity << " and "
                 << destCity << ": ";
            cin >> milesModes.miles;
            cout << "Enter the Transportation Mode"
                 << "(p=plane, f=foot, b=bike, c=car, a=all modes): ";
            cin >> transportationMode;
            switch (tolower(transportationMode))
            {
               case 'p':
                  tMode = PLANE;
                  mode = "Plane";
                  break;
               case 'f':
                  tMode = FOOT;
                  mode = "Foot";
                  break;
               case 'b':
                  tMode = BICYCLE;
                  mode = "Bike";
                  break;
               case 'c':
                  tMode = CAR;
                  mode = "Car";
                  break;
               default:
                  tMode = ALL_MODES;
            }
//            milesModes.miles = milesIn;
            milesModes.modes = tMode;
            mileageChart.addMileage(startCity, destCity, milesModes);
         }
         else
         {
            cout << "\nStart City (e.g. Miami,FL): ";
            cin.ignore();
            getline(cin, startCity);
         }
           
         cin.ignore();  // discard newline character left from "cin>>"
      }
      int m3,d3,y3,h3,min3;
      cout << "Please enter the Start Date (e.g. month day year hour minutes): "; 
      cin >> m3 >> d3 >> y3 >> h3 >> min3;
      Date startDate2(m3,d3,y3,h3,min3,0);    

      int m4,d4,y4,h4,min4;
      cout << "Please enter the Arrival Date (e.g. month day year hour\
 minutes): ";
      cin >> m4 >> d4 >> y4 >> h4 >> min4;
      Date arrivalDate2(m4,d4,y4,h4,min4,0);

      
     Leg legTrip2(startCity,destCity,mode,milesModes.miles,startDate2,arrivalDate2);
     Node<Leg> * noder2 = new Node<Leg>(legTrip2, NULL);

      // hint: insert new leg of the trip at the end of the linked l ist
         if(head == NULL)
         {
            head = noder2;
            endLeg = noder2;
         }
         else
         {
            endLeg -> setLink(noder2);
            endLeg = noder2;
         }
      
      cout << "\nStart City (e.g. Miami,FL): ";
      cin.ignore();
      getline(cin, startCity);
   }
}


//
void Trip :: displayTrip()
{
   cout << endl;
   cout << "Start City           Start Date         Destination City\
     Arrival Date       Mode    Miles\n";
   cout << "-------------------- ----------------   ----------------\
---- ----------------   -----   -----\n";

   // Display the itinerary HERE by traversing through the linked lst!!

     Node<Leg> * pCur = head;
     while (pCur)
     {
        pCur->getData().display();
        pCur = pCur->getLink();
     }
}
   
int Trip :: readFile(string fileName)
{
   cout << "entering read file\n";
   ifstream fin;
   int errorCnt = 0;
   fin.open(fileName.c_str());
   while (fin.fail())
   {
      errorCnt++;
      cout << "File not found! - '" << fileName << "'" << endl;
      if (errorCnt <= 3)
      {
         cout << "\nPlease enter the complete path or correct file name: ";
         getline(cin, fileName);
      }
      else
      {
         cout << "\nI'm sorry, the file '" << fileName
              << "' is not found where specified.  Program terminated.\n";
         exit(1);
      }
      fin.open(fileName.c_str());
   }
   cout << "passed while fin.fail\n";
   // hint: read startCity
   getline(fin, startCity);
   // cout << startCity << endl;

   while (!fin.eof())
   {
      // hint: read  destination city, transportation mode, miles
      getline(fin, destCity);
      getline(fin, transMode);
      fin >> milesBetween;
      // hint: read  month, day, year, hr, min
      int m, d, y, h, min;
      fin >> m >> d >> y >> h >> min;
      // hint: create start date object
      Date startDate(m,d,y,h,min,0);
      // hint: read  month, day, year, hr, min
      int m2, d2, y2, h2, min2;
      fin >> m2 >> d2 >> y2 >> h2 >> min2;
      // hint: create arrival date object
      Date arrivalDate(m2,d2,y2,h2,min2,0);
      // hint: throw away newline characters so next getline() will work.
      fin.ignore(80,'\n');
      // hint: create a Leg object using startCity, destCity, transMode,
      //       miles, startDate, arrivalDate
      Leg legTrip(startCity,destCity,transMode,milesBetween,startDate,arrivalDate);
      Node<Leg> * noder = new Node<Leg>(legTrip, NULL);

      // hint: insert new leg of the trip at the end of the linked list
      if(head == NULL)
      {
         head = noder;
         endLeg = noder;
      }
      else
      {
         endLeg -> setLink(noder);
         endLeg = noder;
      }
      // hint: read next startCity from file
      getline(fin, startCity);
   }
   fin.close();
   return 0;
}

//
void Trip::writeFile(string fileName)
{
   ofstream fout;
   
   fout.open(fileName.c_str());
   if (fout.fail())
   {
      cout << "Output file opening failed.\n";
      exit(1);
   }
   else
   {
//      while(!fout.fail())
      //       {
      // getline(fout, startCity);   
      // fout << endl;
      //  getline(fout, destCity);
      //  fout << endl;
      // getline(fout, transMode);
      //fout << endl;
        //     fout << miles << endl;
//       int m, d, y, h, min;
      //  fout << m << d  << y << h << min << endl;
      //  int m2, d2, y2, h2, min2;
      //  fout << m2 <<  d2 << y2 << h2 << min2 << endl;
      // }
      // fout.close();
      cout << "Trip saved successfully.\n";
   }
}

void Trip::interface()
{
   char option;
   bool displayMenu = true;
   MileageMap mileageChart;         // create a mileage chart  
   while(option!='q')
   {
      if(displayMenu)
      {
         cout << "Welcome to the trip planner 3000!\n"
              << "Please select an option below.\n"
              << "(?) Show these instructions\n"
              << "(p) plan a new trip\n" // sends to the prompt\n
              << "(o) open an old trip\n" // sends to readFile
              << "(d) display current trip\n" // sends to display
            // << "(n) add a destination\n" // utilizes method to add to linked list
            // << "(c) calculate a mileage\n" // calculates the milage
            //  << "(u) update planner\n" // updates
            // << "(a) add a city to the database\n" // <not sure if necessary>
              << "(s) save current trip\n" // saves via writeFile.
              << "(q) quit\n"; // quits
         // <automatically displays after this menu>
      }
          cout << endl;
          cout << ">";
          cin >> option;

          switch(option)
          {
             case '?':
                displayMenu=true;             
               break;
            case 'p':           
               testMileageChart(mileageChart);  // Test the mileage chart
               cout << "selected p\n";
               displayMenu = false;
               break;
            case 'o':
               fileName = getFileName();
               readFile(fileName);//put all the fin stuff in this now
               displayMenu = false;
               break;
            case 'd':
               displayTrip();
               displayMenu = false;
               break;
               //   case    'n':
               //ad d a            destination or next destination
               //  displayMenu = false     ;
               // break;
               //     case 'c'     :
               //mileage
               //  displayMenu     = false;
               //  break;
               //  case 'u':
               //           update();
               // break;
               //  case    'a':
               //add a city
               //  displayMenu     = false;
               //  break;
            case 's':
               fileName = getFileName();
               writeFile(fileName);
               displayMenu = false;
               break;
            case 'q':
               break;
            default:
               cout<< "your defaulting\n";
               displayMenu=false;
               break;
         }
//              cout << ">";
          //            cin >> option;               
//         if (option !='?')
         //       {
         // displayTrip();
         // }
   }
   
}//while(option != 'q');


