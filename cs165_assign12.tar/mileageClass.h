#ifndef MILEAGE_H
#define MILEAGE_H
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <string>
#include <fstream>
#include <map>

using namespace std;


// Global constant
const char PLANE = 0x10;
const char FOOT = 0x01;
const char BICYCLE = 0x02;
const char CAR = 0x04;
const char BUS = 0x08;
const char ALL_MODES = 0x1f;

/****************************************************************************
* Combines the start city and destination cities together to make a "KEY" for
* the STL map.
****************************************************************************/
struct MileageKey
{
   string startCity;
   string destCity;
};

/***************************************************************************
* A struct used for the "data" stored in the STL map.
* int  miles - mileage between cities
* char modes - transportation mode bit mask
* Each bit in the byte represents a transportation mode.
* If the corresponding bit is set, the transportation mode is available. 
* bit 0 = foot, bit 1 = bicycle, bit 2 = car, bit 3 = bus, bit 4 = plane
* Example:  0x1F - all modes available; 0x10 = plane only; 0x01 = foot only
***************************************************************************/
struct MileageData
{
   int miles;   // miles between the two cites
   char modes;  // byte indicating available transportation modes
};

/*****************************************************************************
* Class for creating a Mileage Map used to determine the mileage between
* different cities thoughout the U.S. and some major cities in foreign
* countries. Once the map object is created you call the "getMileage"
* function passing it the start city/state and the destination city/state
* and it will return the mileage between the two cities and the available
* transportation modes.
******************************************************************************/
class MileageMap
{
   public:

      MileageMap();     // default constructor
      MileageMap(string usFileName, string overSeasFileName);
      bool getMileage(string startCity, string destCity, MileageData &milesModes);
      bool addMileage(string startCity, string destCity, MileageData milesModes);
      
   private:
      string fileName;   
      map < MileageKey, MileageData, less < MileageKey > > mileageChart;   
      map < MileageKey, MileageData, less < MileageKey > > readFiles
	(string usFile, string overSeasFile);
      string fixCityStateFormat(string cityState);
      void addToMileageFile(MileageKey key, MileageData milesModes);
      void readDataFile(map < MileageKey, MileageData, less < MileageKey > > &map);
      bool operator < (const MileageKey &rightSide); 
};

#endif
