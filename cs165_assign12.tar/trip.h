//Heres where i will put the stuff i wrote in driver.cpp so that main can just call the class.


#ifndef TRIP_H
#define TRIP_H

#include <iostream>
#include <string>

#include "leg.h"
#include "node.h"
#include "mileageClass.h"

class Trip : public Leg
{
  private: 
   std::string fileName;
   Node<Leg>* head;
   Node<Leg>* endLeg;
   
   
  public:
   //Tripconstructors...
   Trip()
   {
      head = NULL;
      endLeg = NULL;
   }

   std::string getFileName();
   void setFileName(std::string fileName);
   void testMileageChart(MileageMap &theMap);
   void displayTrip();
   int readFile(std::string fileName);
   void writeFile(std::string fileName); //trip?);
   void interface();  
   
};
#endif
