#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <cstdlib>
using namespace std;

#include "leg.h"
#include "node.h"
#include "date.h"
//#include "mileageClass.h"
#include "trip.h"

int main()
{
   Trip myTrip;
   myTrip.interface();

   return 0;
}

/*
//
int getStuff()
{
   string sC,dC;
   cout << "Start City: ";
   getline(cin, sC);
   cout << "Destination City: ";
   getline(cin, dC);
   
   MileageData travelInfo;
   MileageMap map;

   bool found = map.getMileage(sC,dC,travelInfo);
   if(found)
   {
      cout << "a route exists!\n";
      cout << "the distance is: " << travelInfo.miles << endl;
      cout << "the transportation modes available are: ";
      //hex << (int)travelInfo.modes << endl;
      if(travelInfo.modes & PLANE)
      {
         cout << "plane\n";
      }
      if(travelInfo.modes & CAR)
      {
         cout << "car\n";
      }
      if(travelInfo.modes & BIKE)
      {
         cout << "bike\n";
      }
      if(travelInfo.modes & FOOT)
      {
         cout << "Foot\n";
      }
      cout << "Please select a mode of Transportation:(p/c/b/f) ";
      string tM;
      getline(cin, tM);      
   }
   else
   {
      cout << "no information available for those two cities.\n";
      cout << "would you like to create it?: (y/n)";
      char ask;
      cin >> ask;
      if(ask = 'y')
      {
         cout << "need to figure out how to add stuff here..\n";
      }    
   }
}
int readFile()
{
   string fileName;//[80] = "/home/cs165sb/linkedList/trip.dat";
   cout << "What is the name of the trip file to be loaded?: ";
   getLine(cin, fileName);
   ifstream fin;

   int errorCnt = 0;
   fin.open(fileName);
   while (fin.fail())
   {
      errorCnt++;
      cout << "File not found! - '" << fileName << "'" << endl;
      if (errorCnt <= 3)
      {
         cout << "\nPlease enter the complete path or correct file name: ";
         getline(cin, fileName);
      }
      else
      {
         cout << "\nI'm sorry, the file '" << fileName
              << "' is not found where specified.  Program terminated.\n";
         exit(1);
      }
      fin.open(fileName);
   }

// hint: read startCity
   getline(fin, startCity);
// cout << startCity << endl;

   while (!fin.eof())
   {
   // hint: read  destination city, transportation mode, miles
      getline(fin, destCity);
      getline(fin, transMode);
      fin >> miles;
   // hint: read  month, day, year, hr, min
      int m, d, y, h, min;
      fin >> m >> d >> y >> h >> min;
   // hint: create start date object
      Date startDate(m,d,y,h,min,0);
   // hint: read  month, day, year, hr, min
      int m2, d2, y2, h2, min2;
      fin >> m2 >> d2 >> y2 >> h2 >> min2;
   // hint: create arrival date object
      Date arrivalDate(m2,d2,y2,h2,min2,0);
   // hint: throw away newline characters so next getline() will work.
      fin.ignore(80,'\n');
   // hint: create a Leg object using startCity, destCity, transMode,
   //       miles, startDate, arrivalDate
      Leg legTrip(startCity,destCity,transMode,miles,startDate,arrivalDate);
      Node<Leg> * noder = new Node<Leg>(legTrip, NULL);

   // hint: insert new leg of the trip at the end of the linked list
      if(head == NULL)
      {
         head = noder;
         endLeg = noder;
      }
      else
      {
         endLeg -> setLink(noder);
         endLeg = noder;
      }     
   // hint: read next startCity from file
      getline(fin, startCity);
   }
   fin.close();
   
}

//
int writeFile()
{
   ofstream fout;
   string destinationFile;//[256];

   cout << "What file would you like to save your trip as?: ";
   getline(cin, destinationFile);

   fout.open(destinationFile);
   if (fout.fail())
   {
      cout << "Output file opening failed.\n";
      exit(1);
   }
   else
      cout << "Trip saved successfully.\n";

   getline(fout, startCity);
   fout << endl;
   getline(fout, destCity);
   fout << endl;
   getline(fout, transMode);
   fout << endl;
   fout << miles << endl;
   int m, d, y, h, min;
   fout << m << " " << d << " " << y << " " << h << " " << min << "\n";
   int m2, d2, y2, h2, min2;
   fout << m2 << " " <<  d2 << " " <<  y2 << " " << h2 << " " <<  min2 << "\n";
   }
   fout.close();
   return 0;
}
//
void interface()
{
   char option;
   bool displayMenu = true;
   while(option != 'q')
   {
      if(displayMenu)
      {
         cout << "Welcome to the trip planner 3000!\n"
              << "Please select an option below.\n"
              << "(?) Show these instructions\n"
              << "(p) plan a new trip\n" // sends to the prompt\n
              << "(o) open an old trip\n" // sends to readFile
              << "(d) display current trip\n" // sends to display
            // << "(n) add a destination\n" // utilizes method to add to linked list
            // << "(c) calculate a mileage\n" // calculates the milage
              << "(u) update planner\n" // updates
            // << "(a) add a city to the database\n" // <not sure if necessary>
              << "(s) save current trip\n" // saves via writeFile.
              << "(q) quit\n"; // quits
   // <automatically displays after this menu>
         cout << endl;
         cout << ">";
         cin >> option;
         switch(option)
         {
            case '?':
               displayMenu = true;
               break;
            case 'p':
               getStuff();
               displayMenu = false;
               break;
            case 'o':
               readFile();//put all the fin stuff in this now
               displayMenu = false;
               break;
            case 'd':
               display();
               displayMenu = false;
               break;
               //   case    'n':
               //ad d a            destination or next destination
               //  displayMenu = false     ;
               // break;   
               //     case 'c'     :
               //mileage    
               //  displayMenu     = false;
               //  break;  
            case 'u':
//           update();
               break;
               //  case    'a':
               //add a city 
               //  displayMenu     = false;
               //  break;  
            case 's':
               //  writef   ile();
               displayMenu = false;
               break;
            case 'q':
               break;        
            default:
               display();
               break;
         }
         if (option !='?')
         {            
            display();
         }
      }

   }
}

/******************************************************************************
* This program reads in the itinerary from the file trip.dat and stores it into
* a linked list.  The linked list is then displayed showing an itinerary.
*
*  YOU MUST FINISH THIS FUNCTION!!!!!
*
******************************************************************************/
//int main()
//{
//   string startCity;
   // string destCity;
   // string transMode;
   // int miles;

//   Node<Leg>* head = NULL;
   // Node<Leg>* endLeg = head;
// Trip *myTrip;
//  myTrip->interface();
/*   char fileName[80] = "/home/cs165sb/linkedList/trip.dat";
   ifstream fin;

   int errorCnt = 0;
   fin.open(fileName);
   while (fin.fail())
   {
      errorCnt++;
      cout << "File not found! - '" << fileName << "'" << endl;
      if (errorCnt <= 3)
      {
         cout << "\nPlease enter the complete path or correct file name: ";
         cin >> fileName;
      }
      else
      {
         cout << "\nI'm sorry, the file '" << fileName
              << "' is not found were specified.  Exiting the program!!!\n"; 
         exit(1);
      }
      fin.open(fileName);
   }
   
   // hint: read startCity
   getline(fin, startCity);
   // cout << startCity << endl;
   
   while (!fin.eof())
   {
      // hint: read  destination city, transportation mode, miles
      getline(fin, destCity);
      // cout << destCity << endl;      
      getline(fin, transMode);
      // cout << transMode << endl;
      fin >> miles;
      // cout << miles << endl;
     
      // hint: read  month, day, year, hr, min
      int m, d, y, h, min;
      fin >> m >> d >> y >> h >> min;
      // cout << m << " " << d << " " << y << " " << h
      //   << " " << min << endl; 
     
      // hint: create start date object
      Date startDate(m,d,y,h,min,0);
      // hint: read  month, day, year, hr, min
      int m2, d2, y2, h2, min2;
      fin >> m2 >> d2 >> y2 >> h2 >> min2;
      //    cout << m2 << " " << d2 << " " << y2 << " "
      //   << h2 << " " << min2 << endl; 
      
          
      // hint: create arrival date object
      Date arrivalDate(m2,d2,y2,h2,min2,0);
      // hint: throw away newline characters so next getline() will work.
       fin.ignore(80,'\n');

      // hint: create a Leg object using startCity, destCity, transMode,       
      //       miles, startDate, arrivalDate
       Leg legTrip(startCity,destCity,transMode,miles,startDate,arrivalDate);
       Node<Leg> * noder = new Node<Leg>(legTrip, NULL);
       
      // hint: insert new leg of the trip at the end of the linked list
       if(head == NULL)
       {
          head = noder;
          endLeg = noder;
       }
       else
       {
          endLeg -> setLink(noder);
          endLeg = noder;
       }
       
      // hint: read next startCity from file
       getline(fin, startCity);
//       cout << startCity << endl;
   }
      fin.close();
      cout << endl;
      cout << "Start City           Start Date         Destination City     Arriva\
      l Date       Mode    Miles\n";
      cout << "-------------------- ----------------   -------------------- ------\
      ----------   -----   -----\n";

         // Display the itinerary HERE by traversing through the linked list!!

            Node<Leg> * pCur = head;
               while (pCur)
                  {
                        pCur->getData().display();
                              pCur = pCur->getLink();


                                 }
                                 
*/

//   return 0;
//}
