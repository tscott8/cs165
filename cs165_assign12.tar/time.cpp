/***********************************************************************
 * Program:
 *    Assignment 08, Time & Date
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 * Summary:
 *    Time.cpp is where the class in time.h is processed and methods are
 *    are established, so that it knows what to do with the data given.
 *
 *    Estimated:  9.0 hrs
 *    Actual:     9.0 hrs
 *      Comprehension of what to do.
 ************************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

#include "time.h"

//Prompt asks user to input data
void Time :: promptForTime()
{
   //while its getting data from the user its checking to make sure its
   // a valid input.
   bool isValid;
   //do while loops check the input. and reprompts if neccessary
   do
   {
      int hours = 0;
      isValid = true;
      cout << "Hours: ";
      cin >> hours;
      if (cin.fail() || hours < 0 || hours > 23)
      {
         isValid = false;
         cout << "Invalid amount. Please try again.\n";
         cin.clear();
         cin.ignore(256, '\n');
      }
      else
      {
         setHours(hours);
      }
   }while (!isValid);
   
   do
   {
      int minutes = 0;
      isValid = true;
      cout << "Minutes: ";
      cin >> minutes;
      if (cin.fail() || minutes < 0 || minutes > 59)
      {
         isValid = false;
         cout << "Invalid amount. Please try again.\n";
         cin.clear();
         cin.ignore(256, '\n');
      }
      else
      {
         setMinutes(minutes);
      }
   }while (!isValid);
   
   do
   {
      int seconds = 0;
      isValid = true;
      cout << "Seconds: ";
      cin >> seconds;
      if (cin.fail() || seconds < 0 || seconds > 59)
      {
         isValid = false;
         cout << "Invalid amount. Please try again.\n";
         cin.clear();
         cin.ignore(256, '\n');
      }
      else
      {
         setSeconds(seconds);
      }
   }while (!isValid);  
}

//displays the data for the UI
void Time :: displayTime() const 
{

   cout << getHours() << ":";
   if (getMinutes() < 10)
   {
      cout << "0";
   }
   cout << getMinutes() << ":";
  
   if (getSeconds() < 10)
   {
      cout << "0";
   }
   cout << getSeconds();
}

//adds the rollover hours to go back to zero
void Time :: addHours(int hours)
{
   this->hours += hours;
   if (this->hours > 23)
   {
      this->hours -= 24;
   } 
}

//adds the rollover minutes to hours
void Time :: addMinutes(int minutes)
{
   this->minutes += minutes;
   if (this->minutes > 59)
   {
     this->minutes -= 60;
      addHours(1);
   }
}

//adds the rollover seconds to minutes
void Time :: addSeconds(int seconds)
{
   this->seconds += seconds;
   if (this->seconds > 59)
   {
     this->seconds -= 60;
      addMinutes(1);
   }
}

//overloads the + operator
Time operator + (const Time & lhs, const Time & rhs)
{
   Time plus;
   plus.hours = lhs.hours;
   plus.minutes = lhs.minutes;
   plus.seconds = lhs.seconds;
   plus.addHours(rhs.hours);
   plus.addMinutes(rhs.minutes);
   plus.addSeconds(rhs.seconds);
   return plus;
}

//overloads the == operator (is equal)
bool operator == (const Time & lhs, const Time & rhs)
{
   return (lhs.getHours() == rhs.getHours() &&
           lhs.getMinutes() == rhs.getMinutes() &&
           lhs.getSeconds() == rhs.getSeconds());
}

//overloads the != (does not equal) operator
bool operator != (const Time & lhs, const Time & rhs)
{
   return !(lhs==rhs);
}

//overloads the less than operator
bool operator < (const Time & lhs, const Time & rhs)
{
   if (lhs.getHours() < rhs.getHours())
      return true;
   else if (lhs.getHours() == rhs.getHours() &&
            lhs.getMinutes() < rhs.getMinutes())
      return true;
   
   else if (lhs.getHours() == rhs.getHours() &&
            lhs.getMinutes() == rhs.getMinutes() &&
            lhs.getSeconds() < rhs.getSeconds())
      return true;
}

//overloads the less than or equal operator
bool operator <= (const Time & lhs, const Time & rhs)
{
   return (lhs < rhs) || (lhs == rhs);
}
      
//overloads the greater than operator
bool operator > (const Time & lhs, const Time & rhs)
{
   return !(lhs <= rhs);
}

//overloads the greater than or equal operator
bool operator >= (const Time & lhs, const Time & rhs)
{
   return !(lhs < rhs);
}

//overloads the inserstion operator
istream & operator >> (istream & in, Time & rhs)
{
   int hours;
   int minutes;
   int seconds;
   in >> hours;
   in.ignore();
   in >> minutes;
   in.ignore();
   in >> seconds;
   rhs.setHours(hours);
   rhs.setMinutes(minutes);
   rhs.setSeconds(seconds);
   return in;
}

//overloads the extraction operator
ostream & operator << (ostream & out, const Time & rhs)
{
   out << rhs.hours << ":";
   out << setw(2) << setfill('0') << rhs.minutes << ":";
   out << setw(2) << setfill('0') << rhs.seconds;
   return out;
}


