/***********************************************************************
* Program:
*    Assignment 06, Time
*    Brother Burton, CS165
* Author:
*    Tyler Scott
* Summary:
*    Time.h is supposed to be the file where the class "Time" is to be
*    declared so it can be used by other programs
*
*    Estimated:  4.0 hrs
*    Actual:     4.0 hrs
*      Comprehension of what to do.
************************************************************************/
   
#include <iostream>
#ifndef TIME_H
#define TIME_H

//Class Declaration
class Time
{
  private:
   //declare data as a pointer
   int * data;
     
  public:
   //default constructor with data as an array set to 0.
   Time()
   {
      data = new int[3];
      data[0] = 0;
      data[1] = 0;
      data[2] = 0;
   }
   
  //constructor that takes in the data and runs the setters.
   Time(int hours, int minutes, int seconds)
   {
      setHours();
      setMinutes();
      setSeconds();
   }

   //destructor clears the data and array.
   ~Time()
   {
      delete[] data;
      data = NULL;
   }
   
   //variable declarations
   int hours;
   int minutes;
   int seconds;

   //getters
   int getHours() const {return data[0];}
   int getMinutes() const {return data[1];}
   int getSeconds() const {return data[2];}

   //setters
   void setHours()
   {
      data[0] = hours;
   }
   void setMinutes()
   {
      data[1] = minutes;
   }
   void setSeconds()
   {
      data[2] = seconds;
   }

   //
   static bool useMilitaryAsDefault;

   //declaring functions
   void prompt();
   void display() const;
   void displayMilitary() const;
   void displayStandard() const;

   

};

#endif
