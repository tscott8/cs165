/***********************************************************************
 * Program:
 *    Assignment 06, Time
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 * Summary:
 *    Time.cpp is where the class in time.h is processed and methods are
 *    are established, so that it knows what to do with the data given.
 *
 *    Estimated:  4.0 hrs
 *    Actual:     4.0 hrs
 *      Comprehension of what to do.
 ************************************************************************/
#include <iostream>
#include <iomanip>
#include "time.h"
using namespace std;

bool Time :: useMilitaryAsDefault = true;

//Prompt asks user to input data
void Time :: prompt()
{
   //while its getting data from the user its checking to make sure its
   // a valid input.
   bool checkValid;
   do 
   {
      checkValid = true;
      cout << "Hours: ";
      cin >> hours;

      if (hours > 24 || hours < 0)
      {         
         cin.fail();
         while (cin.fail())
         {
            cin.clear();
            cin.ignore(256, '\n');
         }
            cout << "Invalid amount. Please try again.\n";
            checkValid = false;
      }

      else
      {
         setHours();
      }
   }while(!checkValid);

   do
   {
      checkValid = true;
      cout << "Minutes: ";
      cin >> minutes;

      if (minutes > 59 || minutes < 0)
      {
         cin.fail();  
         while (cin.fail())
         {
            cin.clear();
            cin.ignore(256, '\n');
         }
         //if it fails error statement and reprompt
         cout << "Invalid amount. Please try again.\n";
         checkValid = false;
      }
      else
      {
         setMinutes();
      }
   }while(!checkValid);

   do
   {
      checkValid = true;
      cout << "Seconds: ";
      cin >> seconds;
      if (seconds > 59 || seconds < 0)
      {
         cin.fail();
         while (cin.fail())
         {
            cin.clear();
            cin.ignore(256, '\n');
         }
         
         cout << "Invalid amount. Please try again.\n";
         checkValid = false;
      }
      else
      {     
      setSeconds();
      }
   }while(!checkValid);
}

void Time :: display() const
{
   //if the user selected to use military time run that display
   if(useMilitaryAsDefault)
   {
      displayMilitary();
   }
   //if they didnt run standard
   else
   {
      displayStandard();
   }

}   
void Time :: displayMilitary() const
{
   cout << data[0]
        << ":" << setw(2) << setfill('0') << data[1]
        << ":" <<  setw(2) << setfill('0')<< data[2];
  
}
void Time :: displayStandard() const
{
   if (data[0] > 12 && data[0] < 24)
   { 
      cout << data[0] -12 << ":" << setw(2) << setfill('0')
           << data[1] << ":" << setw(2) << setfill('0') << data[2];
   }
   else   
   {
         if (data[0] == 0)
         {
            cout << data[0] + 12;
         }
         else
         {
            cout << data[0];
         }

         cout << ":" << setw(2) << setfill('0') << data[1]
              << ":" <<  setw(2) << setfill('0')<< data[2];     
   }

  
   if (data[0] >= 12 && data[0] < 24)
   {
      cout << " PM";
   }
   else
   {
      cout << " AM";
   }
   
}
