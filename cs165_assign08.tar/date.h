/***********************************************************************
* Program:
*    Assignment 08, Time & Date
*    Brother Burton, CS165
* Author:
*    Tyler Scott
* Summary:
*    Date.h is supposed to be the file where the inherent class "Date" is
*    to be declared so it can be used by other programs. it uses the time
*    class
*
*    Estimated:  9.0 hrs
*    Actual:     9.0 hrs
*      Comprehension of what to do.
************************************************************************/
#ifndef DATE_H
#define DATE_H
#include <iostream>

#include "time.h"


//Class Declaration
class Date : public Time
{
  private:
   int month;
   int day;
   int year;
   
  public:

  //This is the default constructor
  Date() : Time()
   {
      setMonth(1);
      setDay(1);
      setYear(1970);
   }

   //constructor takes in Date data and uses Times default
   Date(int month, int day, int year) : Time()
   {
      setMonth(month);
      setDay(day);
      setYear(year);
   }

   //constructor takes in all the Data. and remembers Times set stuff. 
   Date(int month, int day, int year, int hours, int minutes, int seconds) : Time(hours,minutes,seconds)
   {
      setMonth(month);
      setDay(day);
      setYear(year);
   }

   //another constructor
   Date(const Date & rhs);

   //get and set
   int getMonth() const {return month;}
   void setMonth(int month)
   {   
         if (month > 0 && month <= 12)
         {
            this->month = month;
         }
         else
         {
            throw string("a string");
         } 
   }

   //get and set
   int getDay() const {return day;}
   void setDay(int day)
   {
      if (day > 0 && day <= daysMonth(month, year))
      {
         this->day = day;
      }
      else
      {
         throw string("a string");
      }
   }

   //get and set
   int getYear() const {return year;}
   void setYear(int year)
   {
      if (year > 0)
      {
         this->year = year;
      }
      else
      {
         throw string("a string");
      }
   }
   
   Date & operator = (const Date & rhs);

   //function Declaration
   void promptForDate();
   void displayDate() const;
   
   //from calendar program cs124!
   bool isLeapYear(int year);
   int daysMonth(int month, int year);

   //ADDERS
   void addYears(int year);
   void addMonths(int month);
   void addDays(int day);
   void addHours(int hours);

   //friend zoned redeclaration of extraction operator.
   friend std::ostream & operator << (std::ostream & out, const Date & rhs);
   
};
#endif
