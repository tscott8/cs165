/***********************************************************************
* Program:
*    Assignment 07, Time
*    Brother Burton, CS165
* Author:
*    Tyler Scott
* Summary:
*    Time.h is supposed to be the file where the class "Time" is to be
*    declared so it can be used by other programs
*
*    Estimated:  4.0 hrs
*    Actual:     4.0 hrs
*      Comprehension of what to do.
************************************************************************/
   
#include <iostream>
#ifndef TIME_H
#define TIME_H

//Class Declaration
class Time
{
  private:
   //declare data as a pointer
   int hours;
   int minutes;
   int seconds;

  public:
   //default constructor with data as an array set to 0.
   Time()
   {
      setHours(0);
      setMinutes(0);
      setSeconds(0);
   }
   
  //constructor that takes in the data and runs the setters.
   Time(int hours, int minutes, int seconds)
   {
      setHours(hours);
      setMinutes(minutes);
      setSeconds(seconds);
   }
 
   //getters
   int getHours() const {return hours;/*data[0];*/}
   int getMinutes() const {return minutes;/*data[1];*/}
   int getSeconds() const {return seconds;/*data[2];*/}

   //setters
   void setHours(int hours)
   {
      this->hours = hours;
   }
   void setMinutes(int minutes)
   {
      this->minutes = minutes;
   }
   void setSeconds(int seconds)
   {
      this->seconds = seconds;
   }
   //declaring functions
   void prompt();
   void display() const;
   void checkIt();

   void addHours(int hours)
   {
      hours += hours;
   }
   void addMinutes(int minutes)
       {
      minutes += minutes;
      if (minutes > 59)
      {
         minutes -= 60;
         hours++;
      }            
   }
   void addSeconds(int seconds)
       {
      seconds += seconds;
      if (seconds > 59)
      {
         seconds -= 60;
         minutes++;
         }      
   } 
      
   friend Time operator + (const Time & lhs, const Time & rhs);
   friend Time operator += (const Time & lhs, const Time & rhs);      
};

bool operator == (const Time & lhs, const Time & rhs);
bool operator != (const Time & lhs, const Time & rhs);
bool operator < (const Time & lhs, const Time & rhs);
bool operator <= (const Time & lhs, const Time & rhs);
bool operator > (const Time & lhs, const Time & rhs);
bool operator >= (const Time & lhs, const Time & rhs);
//ostream & operator << (ostream & out, const Time & rhs);
//istream & operator >> (istream & in,  Time & rhs);

#endif
