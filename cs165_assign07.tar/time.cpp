/***********************************************************************
 * Program:
 *    Assignment 07, Time
 *    Brother Burton, CS165
 * Author:
 *    Tyler Scott
 * Summary:
 *    Time.cpp is where the class in time.h is processed and methods are
 *    are established, so that it knows what to do with the data given.
 *
 *    Estimated:  4.0 hrs
 *    Actual:     4.0 hrs
 *      Comprehension of what to do.
 ************************************************************************/
#include <iostream>
#include <iomanip>
#include "time.h"
using namespace std;

//Prompt asks user to input data
void Time :: prompt()
{
   //while its getting data from the user its checking to make sure its
   // a valid input.
   int hours;
   int minutes;
   int seconds;
   char sign;

   cin >> hours >> sign >> minutes >> sign >> seconds;
   setHours(hours);
   setMinutes(minutes);
   setSeconds(seconds);
   
}
void Time :: display() const 
{

   cout << getHours() << ":";
   if (getMinutes() < 10)
   {
      cout << "0";
   }
   cout << getMinutes() << ":";
  
   if (getSeconds() < 10)
   {
      cout << "0";
   }
   cout << getSeconds();
}

bool operator == (const Time & lhs, const Time & rhs)
{
   return (lhs.getHours() == rhs.getHours() &&
           lhs.getMinutes() == rhs.getMinutes() &&
           lhs.getSeconds() == rhs.getSeconds());
}
bool operator != (const Time & lhs, const Time & rhs)
{
   return !(lhs==rhs);
}

bool operator < (const Time & lhs, const Time & rhs)
{
   if (lhs.getHours() < rhs.getHours())
      return true;
   else if (lhs.getHours() == rhs.getHours() &&
            lhs.getMinutes() < rhs.getMinutes())
      return true;
   
   else if (lhs.getHours() == rhs.getHours() &&
            lhs.getMinutes() == rhs.getMinutes() &&
            lhs.getSeconds() < rhs.getSeconds())
      return true;
}

bool operator <= (const Time & lhs, const Time & rhs)
{
   return (lhs < rhs) || (lhs == rhs);
}
      
bool operator > (const Time & lhs, const Time & rhs)
{
   return !(lhs <= rhs);
}
bool operator >= (const Time & lhs, const Time & rhs)
{
   return !(lhs < rhs);
}

Time operator + (const Time & lhs, const Time & rhs)
{
   Time plus;
   plus.hours = lhs.hours + rhs.hours;
   plus.minutes = lhs.minutes + rhs.minutes;
   plus.seconds = lhs.seconds + rhs.seconds;
   return plus;
}
void Time:: checkIt()
{
   if (seconds > 59)
   {
      minutes += 1;
      seconds -= 60;
   }

   if (minutes > 59)
   {
      hours += 1 ;
      minutes -= 60;
   }

   if (hours > 23)
   {
      hours -= 24;
   }
}
/*void Time :: addHours(int hours)
   {
      hours += hours;
   }
void Time :: addMinutes(int minutes)
   {
      minutes += minutes;
      if (minutes > 59)
      {
         minutes -= 60;
         hours++;
      }            
   }
void Time :: addSeconds(int seconds)
   {
      seconds += seconds;
      if (seconds > 59)
      {
         seconds -= 60;
         minutes++;
      }
   } 
*/
