/*****************************************************
 * File: driver.cpp
 * Author: Brother Burton
 *
 * Description: This file helps to test the time class
 *    included int the current directory.
 *
 * You should not need to change this file.
 ****************************************************/

#include <iostream>
using namespace std;

#include "time.h"

// function prototypes
void displayGreeting();

/****************************************************
 * Function: main
 * Prompts the user for three times, then for the type
 * of display, and finally displays the times.
 ****************************************************/
int main()
{
   Time time1;
   Time time2;
   Time time3;

   displayGreeting();

   // input each time object, via their prompt methods
   cout << "Please enter the first time: ";
   time1.prompt();

   cout << "Please enter the second time: ";
   time2.prompt();
  
  
   // set the static member variable, so all times will be
   // in the proper format
 
   // output the times
   cout << "\nYour times are: ";
   
   time1.display();
   cout << ", and ";

   time2.display();
   cout << endl << endl;
   
   cout << "first == second: ";
   if(time1 == time2)
   {
      cout << "true" << endl ;
   }
   else
      cout << "false" << endl;

   cout << "first != second: ";
   if(time1 != time2)
   {
      cout << "true" << endl;
   }
   else
      cout << "false" << endl;

   cout << "first < second: ";
   if(time1 < time2)
   {
      cout << "true" << endl ;
   }
   else
      cout << "false" << endl;

   cout << "first <= second: ";
   if(time1 <= time2)
   {
      cout << "true" << endl ;
   }
   else
      cout << "false" << endl;

   cout << "first > second: ";
   if(time1 > time2)
   {
      cout << "true" << endl ;
   }
   else
      cout << "false" << endl;

   cout << "first >= second: ";
   if(time1 >= time2)
   {
      cout << "true" << endl ;
   }
   else
      cout << "false" << endl;
  
   cout << endl;

   time1.display();
   cout << " + ";
   time2.display();
   cout << " = ";
   time3 = time1 + time2;
   time3.checkIt();
   time3.display();
   cout << endl;

   cout << "After +=, the times are: ";
   time3.display();
   cout << ", ";
   time2.display();
   cout << endl;

   return 0;
}

/*******************************************************
 * Function: displayGreeting
 * Displays the welcome message.
 *******************************************************/
void displayGreeting()
{
   cout << "Welcome to the Time Program.\n" << endl;
}

/*******************************************************
 * Function: getIsMilitaryTime
 * Prompts the user for whether they want military or
 * standard time and returns the value.
 *******************************************************/

// end of file: driver.cpp

