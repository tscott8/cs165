/***********************************************************************
* Program:
*    Assignment 08, Time & Date
*    Brother Burton, CS165
* Author:
*    Tyler Scott
* Summary:
*    Time.h is supposed to be the file where the class "Time" is to be
*    declared so it can be used by other programs
*
*    Estimated:  9.0 hrs
*    Actual:     9.0 hrs
*      Comprehension of what to do.
************************************************************************/
#ifndef TIME_H
#define TIME_H
#include <iostream>

//Class Declaration
class Time
{
  protected://gives access to inherent classes
   int hours;
   int minutes;
   int seconds;

  public:

//default constructor all set to 0.
   Time()
   {
      setHours(0);
      setMinutes(0);
      setSeconds(0);
   }
   
   //constructor that takes in data and runs the setters.
   Time(int hours, int minutes, int seconds)
   {
      setHours(hours);
      setMinutes(minutes);
      setSeconds(seconds);
   }
   
   //getters
   int getHours() const {return hours;}
   int getMinutes() const {return minutes;}
   int getSeconds() const {return seconds;}

   //setters
   void setHours(int hours){this->hours = hours;}
   void setMinutes(int minutes){this->minutes = minutes;}
   void setSeconds(int seconds){this->seconds = seconds;}

   //declaring functions
   void promptForTime();
   void displayTime() const;

   //Adders!
   void addHours(int hours);
   void addMinutes(int minutes);
   void addSeconds(int seconds);

   //member variable assignment operator 
   Time operator = (const Time & rhs)
   {
      this->hours = rhs.hours;
      this->minutes = rhs.minutes;
      this->seconds = rhs.seconds;
      return *this;
   }
   
   //member variable += operator
   Time  operator += (const Time & rhs)      
   {
      this->addHours(rhs.hours);
      this->addMinutes(rhs.minutes);
      this->addSeconds(rhs.seconds);
      return *this;
   }
   
   //friended variable operators.
   friend Time operator + (const Time & lhs, const Time & rhs);
   friend bool operator == (const Time & lhs, const Time & rhs);
   friend bool operator != (const Time & lhs, const Time & rhs);
   friend bool operator < (const Time & lhs, const Time & rhs);
   friend bool operator <= (const Time & lhs, const Time & rhs);
   friend bool operator > (const Time & lhs, const Time & rhs);
   friend bool operator >= (const Time & lhs, const Time & rhs);
   friend std::istream & operator >> (std::istream & in, Time & rhs);
   friend std::ostream & operator << (std::ostream & out, const Time & rhs);

};

#endif
